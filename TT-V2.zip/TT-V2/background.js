let tabDetails;
function _0x1acb(e, t) {
  const n = _0x44a7();
  return (_0x1acb = function (e, t) {
    return n[e -= 420];
  })(e, t);
}
(function (e, t) {
  const o = _0x44a7();
  for (;;) {
    try {
      if (895950 === -parseInt(_0x1acb(517)) / 1 * (-parseInt(_0x1acb(526)) / 2) + parseInt(_0x1acb(473)) / 3 + -parseInt(_0x1acb(475)) / 4 * (-parseInt(_0x1acb(547)) / 5) + parseInt(_0x1acb(537)) / 6 * (parseInt(_0x1acb(420)) / 7) + parseInt(_0x1acb(450)) / 8 + -parseInt(_0x1acb(434)) / 9 * (parseInt(_0x1acb(490)) / 10) + parseInt(_0x1acb(555)) / 11 * (-parseInt(_0x1acb(425)) / 12)) {
        break;
      }
      o.push(o.shift());
    } catch (e) {
      o.push(o.shift());
    }
  }
})();
chrome[_0x1acb(559)][_0x1acb(471) + "d"][_0x1acb(492) + "r"](() => {
  const t = {
    cxlLP: function (e, t) {
      return e === t;
    },
    gSDkh: _0x1acb(447) + _0x1acb(541) + _0x1acb(440) + _0x1acb(482) + _0x1acb(557),
    TSowf: _0x1acb(447) + _0x1acb(541) + _0x1acb(520) + _0x1acb(514) + _0x1acb(511) + _0x1acb(466),
    ERdgA: _0x1acb(487) + _0x1acb(531) + _0x1acb(431) + _0x1acb(512),
    oPrOq: _0x1acb(544) + _0x1acb(519),
    ThXoK: function (e, t) {
      return e(t);
    },
    CIQuN: _0x1acb(487) + _0x1acb(531) + _0x1acb(431) + _0x1acb(483) + _0x1acb(427)
  };
  t[_0x1acb(550)](fetch, t[_0x1acb(493)])[_0x1acb(528)](t => t[_0x1acb(474)]())[_0x1acb(528)](n => {
    if (t[_0x1acb(443)](n[_0x1acb(553)], true)) {
      console[_0x1acb(494)](t[_0x1acb(442)]);
      console[_0x1acb(494)](n[_0x1acb(428)]);
    } else {
      console[_0x1acb(494)](t[_0x1acb(502)]);
      chrome[_0x1acb(559)][_0x1acb(546) + _0x1acb(426)](t[_0x1acb(497)]);
      chrome[_0x1acb(479)][_0x1acb(516) + _0x1acb(481)]();
    }
  })[_0x1acb(465)](n => {
    console[_0x1acb(464)](t[_0x1acb(501)], n);
  });
});
const domain_ip_addresses = [_0x1acb(539) + _0x1acb(508), _0x1acb(542) + _0x1acb(454), _0x1acb(451) + _0x1acb(535)];
let currentKey = null;
function _0x44a7() {
  const e = ["nlqqa", "XuvLn", "243648EuPTNx", "esolve?nam", "examly.io", "fPfsg", "pJtvY", "pageReload", "ion instal", "qWnPf", "gSDkh", "cxlLP", "test?id=", "onMessage", "rCoVR", "NeoExamShi", "name", "s.google/r", "3012912UlXNJj", "35.212.92.", "ocdXf", "fetch IP a", "196", "complete", "mycdetails", "kcgZy", ". Receivin", "https://dn", "Could not ", "ceived", "details?id", "EsKlA", "error", "catch", "onse.", "/test-comp", "Answer", "tabId", "message re", "onInstalle", "onActivate", "3482697LhvmwS", "json", "812264nGNsGZ", "update", "clFWp", "openNewTab", "management", "Fzrwl", "elf", "led and lo", "l.app/api/", "ddress", "NHjaM", "OJXPW", "https://th", "uoByd", "okKWU", "190dOXvQj", "data", "addListene", "CIQuN", "log", "includes", "url", "ERdgA", "windowFocu", "KdWJM", "QEfMK", "oPrOq", "TSowf", "xtensionDa", "action", "some", "xQTVv", "?c_id=", "3.147", "enabled", "hostname", "o API resp", "l.app/temp", "sendMessag", "aded due t", "query", "uninstallS", "916691vSlUXF", "FjKQI", "king API:", "ion not lo", "get", "BHKYZ", "tabs", "iVksq", "g end does", "2RqjtDI", "darwr", "then", "fSDhp", "key", "ottathukid", "getAll", "find", "extension", "221", "mycourses/", "401208iWhDKK", " not exist", "142.250.19", "length", "eld extens", "34.233.30.", "AdnZM", "Error chec", "type", "setUninsta", "25ZjJqUt", "lastError", "Failed to ", "ThXoK", "establish ", "filter", "status", "create", "9156697SGuvgq", "GDZLp", "aded.", "eld", "runtime", "133AicHCz", "examly.tes", "getUrlAndE", "connection", "examly.net", "48AgHiEU", "llURL", "temp", "message", "atibility", "onUpdated", "uven.verce"];
  return (_0x44a7 = function () {
    return e;
  })();
}
const urlPatterns = [_0x1acb(536) + _0x1acb(462) + "=", _0x1acb(444), _0x1acb(456) + _0x1acb(507), _0x1acb(467) + _0x1acb(429)];
function fetchExtensionDetails(e) {
  const n = {
    okKWU: function (e, t, n) {
      return e(t, n);
    }
  };
  chrome[_0x1acb(479)][_0x1acb(532)](o => {
    const a = o[_0x1acb(552)](e => e[_0x1acb(509)] && e[_0x1acb(448)] === _0x1acb(447) + _0x1acb(558) && e[_0x1acb(545)] === _0x1acb(534));
    const r = a[_0x1acb(552)](e => e[_0x1acb(509)] && e[_0x1acb(448)] !== _0x1acb(447) + _0x1acb(558) && e[_0x1acb(545)] === _0x1acb(534))[_0x1acb(540)];
    n[_0x1acb(489)](e, a, r);
  });
}
const fetchDomainIp = e => {
  const t = {
    darwr: function (e, t) {
      return e(t);
    },
    qWnPf: function (e, t) {
      return e(t);
    },
    xQTVv: function (e, t) {
      return e(t);
    }
  };
  return new Promise(n => {
    const c = new URL(e)[_0x1acb(510)];
    t[_0x1acb(506)](fetch, _0x1acb(459) + _0x1acb(449) + _0x1acb(435) + "e=" + c)[_0x1acb(528)](e => e[_0x1acb(474)]())[_0x1acb(528)](e => {
      const a = e[_0x1acb(468)][_0x1acb(533)](e => 1 === e[_0x1acb(545)])?.[_0x1acb(491)] || null;
      t[_0x1acb(527)](n, a);
    })[_0x1acb(465)](() => {
      t[_0x1acb(441)](n, null);
    });
  });
};
async function handleUrlChange() {
  const t = {
    fSDhp: function (e, t) {
      return e === t;
    },
    kcgZy: _0x1acb(460) + _0x1acb(551) + _0x1acb(423) + _0x1acb(458) + _0x1acb(525) + _0x1acb(538) + ".",
    XuvLn: _0x1acb(422) + _0x1acb(503) + "ta",
    GDZLp: function (e, t) {
      return e(t);
    },
    OJXPW: _0x1acb(424),
    KdWJM: _0x1acb(421) + "t",
    rCoVR: _0x1acb(436),
    BHKYZ: function (e, t) {
      return e(t);
    },
    FjKQI: _0x1acb(549) + _0x1acb(453) + _0x1acb(484)
  };
  if (urlPatterns[_0x1acb(505)](t => tabDetails[_0x1acb(496)][_0x1acb(495)](t))) {
    let n = await t[_0x1acb(556)](fetchDomainIp, tabDetails[_0x1acb(496)]);
    if (n && domain_ip_addresses[_0x1acb(495)](n) || tabDetails[_0x1acb(496)][_0x1acb(495)](t[_0x1acb(486)]) || tabDetails[_0x1acb(496)][_0x1acb(495)](t[_0x1acb(499)]) || tabDetails[_0x1acb(496)][_0x1acb(495)](t[_0x1acb(446)])) {
      t[_0x1acb(522)](fetchExtensionDetails, (n, o) => {
        let a = {
          action: t[_0x1acb(433)],
          url: tabDetails[_0x1acb(496)],
          enabledExtensionCount: o,
          extensions: n,
          id: tabDetails.id,
          currentKey: currentKey
        };
        chrome[_0x1acb(523)][_0x1acb(513) + "e"](tabDetails.id, a, e => {
          if (chrome[_0x1acb(559)][_0x1acb(548)] && t[_0x1acb(529)](chrome[_0x1acb(559)][_0x1acb(548)][_0x1acb(428)], t[_0x1acb(457)])) {
            chrome[_0x1acb(523)][_0x1acb(476)](tabDetails.id, {
              url: tabDetails[_0x1acb(496)]
            });
          }
        });
      });
    } else {
      console[_0x1acb(494)](t[_0x1acb(518)]);
    }
  }
}
function openNewMinimizedWindowWithUrl(e) {
  chrome[_0x1acb(523)][_0x1acb(554)]({
    url: e
  }, e => {});
}
chrome[_0x1acb(559)][_0x1acb(471) + "d"][_0x1acb(492) + "r"](() => {
  chrome[_0x1acb(523)][_0x1acb(515)]({
    active: true,
    currentWindow: true
  }, t => {
    chrome[_0x1acb(523)][_0x1acb(476)](t[0].id, {
      url: t[0][_0x1acb(496)]
    });
  });
});
chrome[_0x1acb(523)][_0x1acb(472) + "d"][_0x1acb(492) + "r"](e => {
  chrome[_0x1acb(523)][_0x1acb(521)](e[_0x1acb(469)], e => {
    tabDetails = e;
  });
});
chrome[_0x1acb(523)][_0x1acb(430)][_0x1acb(492) + "r"]((e, t, n) => {
  const c = {
    uoByd: function (e, t) {
      return e === t;
    },
    clFWp: _0x1acb(455),
    fPfsg: function (e) {
      return e();
    }
  };
  if (c[_0x1acb(488)](t[_0x1acb(553)], c[_0x1acb(477)])) {
    tabDetails = n;
    c[_0x1acb(437)](handleUrlChange);
  }
});
chrome[_0x1acb(559)][_0x1acb(445)][_0x1acb(492) + "r"]((e, t, n) => {
  const c = {
    Fzrwl: _0x1acb(470) + _0x1acb(461),
    nlqqa: function (e, t) {
      return e === t;
    },
    iVksq: _0x1acb(439) + "ed",
    AdnZM: function (e, t) {
      return e === t;
    },
    ocdXf: _0x1acb(498) + "s",
    NHjaM: function (e) {
      return e();
    },
    QEfMK: function (e, t) {
      return e === t;
    },
    EsKlA: _0x1acb(478),
    pJtvY: function (e, t) {
      return e(t);
    }
  };
  console[_0x1acb(494)](c[_0x1acb(480)], e);
  currentKey = e[_0x1acb(530)];
  if (c[_0x1acb(432)](e[_0x1acb(504)], c[_0x1acb(524)]) || c[_0x1acb(543)](e[_0x1acb(504)], c[_0x1acb(452)])) {
    c[_0x1acb(485)](handleUrlChange);
  } else if (c[_0x1acb(500)](e[_0x1acb(504)], c[_0x1acb(463)])) {
    c[_0x1acb(438)](openNewMinimizedWindowWithUrl, e[_0x1acb(496)]);
  }
});
const notify = async (e, t, n = "E") => {
  e = e || (await chrome.tabs.query({
    active: true,
    lastFocusedWindow: true
  }))[0].id;
  chrome.action.setBadgeText({
    tabId: e,
    text: n
  });
  chrome.action.setTitle({
    tabId: e,
    title: t
  });
};
const activate = () => {
  if (activate.busy) {
    return;
  }
  activate.busy = true;
  try {
    chrome.scripting.unregisterContentScripts();
    const e = {
      allFrames: true,
      matchOriginAsFallback: true,
      runAt: "document_start",
      matches: ["*://*/*"]
    };
    chrome.scripting.registerContentScripts([{
      ...e,
      id: "main",
      js: ["data/inject/main.js"],
      world: "MAIN"
    }, {
      ...e,
      id: "isolated",
      js: ["data/inject/isolated.js"],
      world: "ISOLATED"
    }]);
  } catch (e) {
    notify(undefined, "Blocker Registration Failed: " + e.message);
    console.error("Blocker Registration Failed", e);
  }
  for (const e of activate.actions) e();
  activate.actions.length = 0;
  activate.busy = false;
};
chrome.runtime.onStartup.addListener(activate);
chrome.runtime.onInstalled.addListener(activate);
activate.actions = [];
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "copySelectedText",
    title: "Copy",
    contexts: ["selection"]
  });
  chrome.contextMenus.create({
    id: "separator1",
    type: "separator",
    contexts: ["editable", "selection"]
  });
  chrome.contextMenus.create({
    id: "pasteClipboard",
    title: "Paste Clipboard Contents by Swapping",
    contexts: ["editable"]
  });
  chrome.contextMenus.create({
    id: "typeClipboard",
    title: "Type Clipboard",
    contexts: ["editable"]
  });
  chrome.contextMenus.create({
    id: "separator2",
    type: "separator",
    contexts: ["editable", "selection"]
  });
  chrome.contextMenus.create({
    id: "searchWithOpenAI",
    title: "Search with OpenAI",
    contexts: ["selection"]
  });
  chrome.contextMenus.create({
    id: "solveMCQ",
    title: "Solve MCQ",
    contexts: ["selection"]
  });
});
function showOverlay(e) {
  chrome.scripting.executeScript({
    target: {
      tabId: e
    },
    func: function (e) {
      if (document.getElementById("openai-overlay")) {
        return void document.getElementById("openai-overlay").remove();
      }
      const t = document.createElement("div");
      t.innerHTML = e;
      document.body.appendChild(t);
      const n = document.getElementById("openai-textbox");
      n.focus();
      n.addEventListener("keydown", function (e) {
        if ("Enter" === e.key && e.shiftKey) {
          document.getElementById("openai-overlay").remove();
        }
      });
      document.addEventListener("keydown", function (e) {
        if ("Escape" === e.key) {
          document.getElementById("openai-overlay").remove();
        }
      });
    },
    args: ["\n  <div id=\"openai-overlay\" style=\"position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.8); display: flex; align-items: center; justify-content: center; z-index: 9999;\">\n      <div style=\"width: 40%; padding: 20px; background-color: #2c2c2c; border: 1px solid #444; border-radius: 8px;\">\n          <div id=\"prompt-suggestions\" style=\"margin-bottom: 10px;\">\n              <span style=\"color: #888; cursor: pointer;\" onclick=\"document.getElementById('openai-textbox').value = 'Secret Textbox'\">Press [Esc] to exit</span>\n          </div>\n          <textarea id=\"openai-textbox\" style=\"width: 100%; height: 100px; padding: 10px 10px; font-size: 16px; background-color: #2c2c2c; color: #ffffff; border: none; border-radius: 8px; resize: vertical; outline: none;\"></textarea>\n      </div>\n  </div>\n  "]
  });
}
function _0x49f3(e, t) {
  const n = _0x24b5();
  return (_0x49f3 = function (e, t) {
    return n[e -= 421];
  })(e, t);
}
async function checkForUpdate() {
  const t = {
    hFmZk: function (e, t) {
      return e(t);
    },
    CIyNa: _0x49f3(427) + _0x49f3(422) + _0x49f3(444) + _0x49f3(450) + _0x49f3(421),
    iTZNT: function (e, t) {
      return e > t;
    },
    CfcSM: function (e, t) {
      return e(t);
    },
    RMlEp: _0x49f3(445) + _0x49f3(442) + _0x49f3(431),
    ayhPz: _0x49f3(426)
  };
  const n = await t[_0x49f3(439)](fetch, t[_0x49f3(449)]);
  const o = (await n[_0x49f3(441)]())[_0x49f3(421)];
  const c = chrome[_0x49f3(430)][_0x49f3(423) + "t"]()[_0x49f3(421)];
  return !t[_0x49f3(428)](t[_0x49f3(446)](parseFloat, o), t[_0x49f3(439)](parseFloat, c)) || (chrome[_0x49f3(438)][_0x49f3(435)]({
    url: t[_0x49f3(424)],
    type: t[_0x49f3(448)],
    width: 100,
    height: 100
  }), false);
}
function _0x24b5() {
  const e = ["3038776FMAzwl", "runtime", "pup.html", "297uOltVN", "3324uztoBN", "564aiyavZ", "create", "980NRWpHO", "26165nuCuca", "windows", "hFmZk", "2398188VRYlNU", "json", "e/updatePo", "8192202xFBIRw", "uven.verce", "data/updat", "CfcSM", "649NPUmHr", "ayhPz", "CIyNa", "l.app/api/", "149Mkqmlh", "7eKaCSg", "version", "ottathukid", "getManifes", "RMlEp", "3810GuZclN", "popup", "https://th", "iTZNT"];
  return (_0x24b5 = function () {
    return e;
  })();
}
function showHelpToast() {
  if (document.getElementById("image-toast-overlay")) {
    return void document.getElementById("image-toast-overlay").remove();
  }
  const t = document.createElement("div");
  t.id = "image-toast-overlay";
  t.innerHTML = "<img src=\"https://i.imgur.com/qEQuh64.png\" style=\"width: 255px; height: auto;\">";
  t.style.cssText = "position: fixed; bottom: 20px; right: 20px; z-index: 9999;";
  document.body.appendChild(t);
  setTimeout(() => {
    if (document.getElementById("image-toast-overlay")) {
      document.getElementById("image-toast-overlay").remove();
    }
  }, 5e3);
  document.addEventListener("keydown", function t(n) {
    if ("Escape" === n.key && document.getElementById("image-toast-overlay")) {
      document.getElementById("image-toast-overlay").remove();
      document.removeEventListener("keydown", t);
    }
  });
}
function getSelectedText() {
  return window.getSelection().toString();
}
function handleQueryResponse(e, t, n = false) {
  if (e) {
    if (n) {
      showMCQToast(t, e);
    } else {
      copyToClipboard(e);
      showToast(t, "Successful!");
    }
  } else {
    showToast(t, "Error. Try again after 30s.", true);
  }
}
!function (e, t) {
  const o = _0x24b5();
  for (;;) {
    try {
      if (760269 === parseInt(_0x49f3(451)) / 1 * (parseInt(_0x49f3(433)) / 2) + parseInt(_0x49f3(440)) / 3 + parseInt(_0x49f3(436)) / 4 * (-parseInt(_0x49f3(437)) / 5) + parseInt(_0x49f3(443)) / 6 * (parseInt(_0x49f3(452)) / 7) + -parseInt(_0x49f3(429)) / 8 + -parseInt(_0x49f3(432)) / 9 * (-parseInt(_0x49f3(425)) / 10) + -parseInt(_0x49f3(447)) / 11 * (parseInt(_0x49f3(434)) / 12)) {
        break;
      }
      o.push(o.shift());
    } catch (e) {
      o.push(o.shift());
    }
  }
}();
chrome.contextMenus.onClicked.addListener(async (e, t) => {
  if (await checkForUpdate()) {
    if ("copySelectedText" === e.menuItemId && e.selectionText) {
      chrome.scripting.executeScript({
        target: {
          tabId: t.id
        },
        func: e => {
          const t = document.createElement("textarea");
          t.textContent = e;
          document.body.appendChild(t);
          t.select();
          document.execCommand("copy");
          document.body.removeChild(t);
        },
        args: [e.selectionText]
      });
    }
    if ("typeClipboard" === e.menuItemId) {
      chrome.scripting.executeScript({
        target: {
          tabId: t.id
        },
        func: async () => {
          const e = await navigator.clipboard.readText();
          const t = document.activeElement;
          for (let n of e) {
            const e = new KeyboardEvent("keydown", {
              key: n,
              code: "Key" + n.toUpperCase(),
              charCode: n.charCodeAt(0),
              keyCode: n.charCodeAt(0),
              which: n.charCodeAt(0),
              bubbles: true
            });
            const o = new KeyboardEvent("keypress", {
              key: n,
              code: "Key" + n.toUpperCase(),
              charCode: n.charCodeAt(0),
              keyCode: n.charCodeAt(0),
              which: n.charCodeAt(0),
              bubbles: true
            });
            const c = new InputEvent("input", {
              data: n,
              inputType: "insertText",
              bubbles: true
            });
            t.dispatchEvent(e);
            t.dispatchEvent(o);
            t.value += n;
            t.dispatchEvent(c);
          }
        }
      });
    }
    if ("pasteClipboard" === e.menuItemId) {
      chrome.scripting.executeScript({
        target: {
          tabId: t.id
        },
        func: async () => {
          const e = await navigator.clipboard.readText();
          document.activeElement.value = e;
          document.activeElement.dispatchEvent(new Event("input", {
            bubbles: true
          }));
        }
      });
    }
    if ("searchWithOpenAI" === e.menuItemId && e.selectionText) {
      handleQueryResponse(await queryOpenAI(e.selectionText), t.id);
    }
    if ("solveMCQ" === e.menuItemId && e.selectionText) {
      handleQueryResponse(await queryOpenAI(e.selectionText, true), t.id, true);
    }
  }
});
chrome.commands.onCommand.addListener(function (e) {
  if ("show-overlay" === e) {
    chrome.tabs.query({
      active: true,
      currentWindow: true
    }, function (e) {
      if (e[0]) {
        showOverlay(e[0].id);
      }
    });
  }
});
chrome.commands.onCommand.addListener((e, t) => {
  if ("custom-paste" === e) {
    chrome.scripting.executeScript({
      target: {
        tabId: t.id
      },
      func: async () => {
        const e = await navigator.clipboard.readText();
        const t = document.querySelector("#chat-overlay div[contenteditable=\"true\"]");
        if (t) {
          t.innerText += e;
          const n = new Event("input", {
            bubbles: true
          });
          t.dispatchEvent(n);
        }
      }
    });
  }
  if ("search-mcq" === e) {
    chrome.scripting.executeScript({
      target: {
        tabId: t.id
      },
      function: getSelectedText
    }, async n => {
      if (n[0]) {
        const o = "search-mcq" === e;
        handleQueryResponse(await queryOpenAI(n[0].result, o), t.id, o);
      }
    });
  }
  if ("custom-copy" === e) {
    chrome.scripting.executeScript({
      target: {
        tabId: t.id
      },
      function: () => {
        const e = window.getSelection().toString();
        const t = document.createElement("textarea");
        t.textContent = e;
        document.body.appendChild(t);
        t.select();
        document.execCommand("copy");
        document.body.removeChild(t);
      }
    });
  }
  if ("custom-paste" === e) {
    chrome.scripting.executeScript({
      target: {
        tabId: t.id
      },
      func: async () => {
        const e = await navigator.clipboard.readText();
        document.activeElement.value = e;
        document.activeElement.dispatchEvent(new Event("input", {
          bubbles: true
        }));
      }
    });
  }
  if ("show-help" === e) {
    chrome.scripting.executeScript({
      target: {
        tabId: t.id
      },
      function: showHelpToast
    });
  }
  if ("toggle-chat" === e) {
    chrome.tabs.query({
      active: true,
      currentWindow: true
    }, e => {
      chrome.tabs.sendMessage(e[0].id, {
        action: "toggleChatOverlay"
      });
    });
  }
});
let chatContext = [];
async function processChatMessage(e) {
  const t = await queryOpenAI(e, false, chatContext);
  if (t) {
    chatContext.push({
      role: "assistant",
      content: t
    });
    chrome.tabs.query({
      active: true,
      currentWindow: true
    }, e => {
      chrome.tabs.sendMessage(e[0].id, {
        action: "updateChatHistory",
        role: "assistant",
        content: t
      });
    });
  }
}
function _0x4010(e, t) {
  const n = _0x2c04();
  return (_0x4010 = function (e, t) {
    return n[e -= 247];
  })(e, t);
}
async function queryOpenAI(e, t = false, n = []) {
    const apiEndpoint = "https://openrouter.ai/api/v1/chat/completions"; // OpenRouter AI endpoint
    const apiKey = "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"; // Your API key
  
    // Handling additional params if 't' is true
    if (t) {
      e += " additional text if needed";
    }
  
    // Create the messages array for the OpenRouter request
    const messages = [
      { role: "system", content: "You are a helpful assistant." },
      ...(Array.isArray(n) ? n : []),
      { role: "user", content: e }
    ];
  
    try {
      // Sending request to OpenRouter API
      const response = await fetch(apiEndpoint, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${apiKey}`, // Include your API key here
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model: "nousresearch/hermes-3-llama-3.1-405b:free", // Replace with model available on OpenRouter
          messages: messages
        })
      });
  
      // Handle non-successful responses
      if (!response.ok) {
        console.error("Error with API response:", response);
        const errorText = await response.text();
        console.error("Error details:", errorText);
        return null;
      }
  
      // If successful, parse and return the response
      const data = await response.json();
      return data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content.trim();
    } catch (error) {
      console.error("Error occurred during OpenAI request:", error);
      return null;
    }
  }
  
function _0x2c04() {
  const e = ["211994mFuAeo", "cVaiD", " MCQ quest", " : <option", "MCQ, just ", "applicatio", "n>. If you", "Error quer", "4umTliV", "ion. The o", "XVUbl", "utput shou", "message", "PNKEn", "n/json", "gpt-4o", "QTmSF", "\nThis is a", "uven.verce", "stringify", "isArray", "system", "log", "error", "helpful as", "Bearer ", "nswer opti", "120vthzdI", "er and the", "ottathukid", " question ", "Not an MCQ", "o-schemati", "content", "on alone. ", " no.>. <an", "9GdnDQL", "json", "phajm", "https://th", "l.app/api/", "while quer", "856340TvPudY", "3651306jrODIK", "y explanat", "choices", "is not an ", "You are a ", "Exception ", "give the o", "OpenAI res", "user", "part-of-nw", "ld be in t", "No need an", "cHoTu", "POST", "trim", "only say `", "ecLJf", " correct a", "sistant.", "7083560QuCNQk", " think the", "ion, Just ", "swer optio", "342181WDFPiu", "dNWTw", "CKCoZ", "ying OpenA", "544512FYZaDi", "proxy", "zSaUw", "ption numb", "HEoVi", "3114355DYQGxD", "LWVRW", "ponse:", "HNaLr", "6wnUOxk", "his format"];
  return (_0x2c04 = function () {
    return e;
  })();
}
function copyToClipboard(e) {
  chrome.tabs.query({
    active: true,
    currentWindow: true
  }, function (t) {
    if (t[0]) {
      chrome.scripting.executeScript({
        target: {
          tabId: t[0].id
        },
        func: function (e) {
          const t = document.createElement("textarea");
          t.textContent = e;
          document.body.appendChild(t);
          t.select();
          document.execCommand("copy");
          document.body.removeChild(t);
        },
        args: [e]
      });
    }
  });
}
function showToast(e, t, n = false) {
  chrome.scripting.executeScript({
    target: {
      tabId: e
    },
    func: function (e, t) {
      const n = document.createElement("div");
      n.textContent = e;
      n.style.position = "fixed";
      n.style.bottom = "20px";
      n.style.right = "20px";
      n.style.backgroundColor = "black";
      n.style.color = t ? "red" : "white";
      n.style.padding = "10px";
      n.style.borderRadius = "5px";
      n.style.zIndex = 1e3;
      const o = document.createElement("span");
      o.textContent = "‎ ‎ ‎ ◉";
      o.style.float = "right";
      o.style.cursor = "pointer";
      o.onclick = function () {
        n.remove();
      };
      n.appendChild(o);
      document.body.appendChild(n);
      setTimeout(() => {
        n.remove();
      }, 5e3);
    },
    args: [t, n]
  });
}
function showMCQToast(e, t) {
  chrome.scripting.executeScript({
    target: {
      tabId: e
    },
    func: function (e) {
      const [t, ...n] = e.split(" ");
      const c = document.createElement("div");
      c.innerHTML = `<b>${t}</b>‎ ‎ ${n.join("‎ ")}`;
      c.style.position = "fixed";
      c.style.bottom = "10px";
      c.style.left = "50%";
      c.style.transform = "translateX(-50%)";
      c.style.backgroundColor = "black";
      c.style.color = "white";
      c.style.padding = "15px";
      c.style.borderRadius = "5px";
      c.style.zIndex = 1e3;
      c.style.fontSize = "16px";
      c.style.textAlign = "center";
      c.style.maxWidth = "80%";
      const a = document.createElement("span");
      a.innerHTML = "&times;";
      a.style.float = "right";
      a.style.cursor = "pointer";
      a.style.marginLeft = "10px";
      a.onclick = function () {
        c.remove();
      };
      c.appendChild(a);
      document.body.appendChild(c);
      setTimeout(() => {
        c.remove();
      }, 5e3);
    },
    args: [t]
  });
}
function showAlert(e, t) {
  chrome.scripting.executeScript({
    target: {
      tabId: e
    },
    func: function (e) {
      alert(e);
    },
    args: [t]
  });
}
function copyToClipboard(e) {
  chrome.tabs.query({
    active: true,
    currentWindow: true
  }, function (t) {
    if (t[0]) {
      chrome.scripting.executeScript({
        target: {
          tabId: t[0].id
        },
        func: function (e) {
          const t = document.createElement("textarea");
          t.textContent = e;
          document.body.appendChild(t);
          t.select();
          document.execCommand("copy");
          document.body.removeChild(t);
        },
        args: [e]
      });
    }
  });
}
chrome.runtime.onMessage.addListener((e, t, n) => {
  if ("processChatMessage" === e.action) {
    const {
      message: t,
      context: n
    } = e;
    chatContext = n;
    processChatMessage(t);
  } else if ("resetContext" === e.action) {
    chatContext = [];
  }
});
(function (e, t) {
  const o = _0x2c04();
  for (;;) {
    try {
      if (549385 === -parseInt(_0x4010(325)) / 1 + parseInt(_0x4010(323)) / 2 * (-parseInt(_0x4010(314)) / 3) + parseInt(_0x4010(252)) / 4 * (parseInt(_0x4010(319)) / 5) + -parseInt(_0x4010(287)) / 6 + -parseInt(_0x4010(310)) / 7 * (-parseInt(_0x4010(271)) / 8) + parseInt(_0x4010(280)) / 9 * (-parseInt(_0x4010(286)) / 10) + parseInt(_0x4010(306)) / 11) {
        break;
      }
      o.push(o.shift());
    } catch (e) {
      o.push(o.shift());
    }
  }
})();
function copyToClipboard(text) {
  chrome.tabs.query({
    active: true,
    currentWindow: true
  }, function (tabs) {
    if (tabs[0]) {
      chrome.scripting.executeScript({
        target: {
          tabId: tabs[0].id
        },
        func: function (content) {
          const textarea = document.createElement('textarea');
          textarea.textContent = content;
          document.body.appendChild(textarea);
          textarea.select();
          document.execCommand('copy');
          document.body.removeChild(textarea);
        },
        args: [text]
      });
    }
  });
}